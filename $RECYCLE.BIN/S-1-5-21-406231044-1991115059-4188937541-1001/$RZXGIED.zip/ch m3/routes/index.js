'use strict'

const models = require('../models/model')
const express = require('express')
const { response } = require('../app')
const { json } = require('body-parser')

const router = express.Router()
module.exports = router

// Escriban sus rutas acá
// Siéntanse libres de dividir entre archivos si lo necesitan
const users = [];

router.get('/users', (req, res) => {
    res.json(users)
})
router.get('/users',(req,res)=>{
    let addUser = req.body
    users.push(addUser)
    json(users)
})
router.post('/users',(req,res)=>{
    const { email, name } = req.body;
    if (req.body.email) {
        res.sendStatus(201).json(users)
    }else{
        res.status(400).json({error: 'El usuario ya existe' })
    }
    
})
// Hint:  investigá las propiedades del objeto Error en JS para acceder al mensaje en el mismo.