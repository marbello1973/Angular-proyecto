# Checkpoint M3

_We start the M3 checkpoint. As was customary in these last tasks, we started with a paragraph translated in Google Translate LOL. Successes!_



## Comenzando 🔧

🚀`npm install`  
🚀Podes correr `npm test` para ejecutar los test.  
🚀Revisen la estructura del proyecto.  
🚀Empiecen a trabajar en base a los test. Cambien el xit por un it cuando el test este listo para correr.  
Hagan `git commit` a medida que van pasando los test.  




### Notas al pie 📋

* Sacate todas las dudas y participá si podés. 📢
* Cortá con un ☕ o un poco de aire si necesitás descansar 😊. 



---
hecho con ❤️.
