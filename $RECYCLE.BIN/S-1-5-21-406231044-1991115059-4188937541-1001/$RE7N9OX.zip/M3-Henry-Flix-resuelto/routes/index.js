'use strict'

const models = require('../models/model'); // lo llamo así o puedo llamarlo como lo hago en la línea 5
const express = require('express');
const {listUsers, addUser, switchPlan, listSeries, addSerie, play, watchAgain, rateSerie} = require('../models/model.js');
const router = express.Router();

// router.use(express.json()); no hace falta xq ya puse el midelware en el archivo abre app.js


// Escriban sus rutas acá
// Siéntanse libres de dividir entre archivos si lo necesitan
router.get("/users", function (req, res, next) {
    res.status(200).json(listUsers())
  });

router.post("/users", function (req, res, next) {

    // const msg=addUser(req.body.email,req.body.name)
    // if(msg.message!==Error){
    //     console.log('entra ok')
    //     res.status(201).json({msg:msg})
    // }
    
    //     res.status(400).json({ error: 'El usuario ya existe' })
    
    
    try{
        res.status(201).json({msg:addUser(req.body.email,req.body.name)})
    }
    catch(error){
        res.status(400).json({ error: 'El usuario ya existe' })
    }
    
});

router.patch("/users/plan", function (req, res, next) {
    const{user}=req.query
    try{
        res.status(200).json({msg:switchPlan(user)})

    }
    catch(error){
        res.status(404).json({ error: 'Usuario inexistente'  })
    }
  });

router.get("/series", function (req, res, next) {
    res.status(200).json(listSeries())
  });

  router.post("/series", function (req, res, next) {
    const{name, seasons, category, year}=req.body
    try{
        let msg=addSerie(name, seasons, category, year)
        res.status(201).json({msg:msg})
    }
    catch(error){
        console.log(error.message)
        res.status(400).json({ error: error.message})
    }
    
})

router.get("/series/:category", function (req, res, next) {
    const {category}=req.params
    // console.log(category)
    try{

        res.status(200).json(listSeries(category))
    }
    catch{
        res.status(404).json({ error: 'La categoría platinum no existe' })
    }
    // res.send('que pasa')
  });

  router.get("/play/:serie", function (req, res, next){
            const{serie}=req.params
            const{user}=req.query
            // console.log(serie,user)    
            try{
                let msg=play(serie,user)
                res.status(200).json({ msg: msg })
            }
            catch(error){
                res.status(404).json({ error: error.message})
            }            
  })
  
  router.get("/watchAgain", function (req, res, next){
    const {user}=req.query
    try{
        let vistas=watchAgain(user)
        res.status(200).json(vistas)

    }
    catch(error){
        res.status(404).json({ error: error.message })
    }
    

  })

  router.post("/rating/:serie",function(req,res){
    const {serie}=req.params
    const{email,score}=req.body
    try{
        let mensaje=rateSerie(serie,email,score)
        res.status(200).json({ msg: mensaje })
    }
    catch(error){
        res.status(404).json({ error: error.message })
    }
  })
// Hint:  investigá las propiedades del objeto Error en JS para acceder al mensaje en el mismo.
module.exports = router