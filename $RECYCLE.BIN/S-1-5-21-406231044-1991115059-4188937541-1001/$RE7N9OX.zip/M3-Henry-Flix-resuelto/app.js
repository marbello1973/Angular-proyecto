'use strict'
const router = require('./routes');
const express = require('express');
const Model = require('./models/model');



const app = express();

// Acuérdense de agregar su router o cualquier middleware que necesiten acá.

app.use(express.json()); // alternatriva a app.use(bodyParser.json()); primero hay qye hacer el require del componente
app.use('/', router);


module.exports = app;
