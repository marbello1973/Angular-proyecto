const { Router } = require("express");
const router = Router();

// Aqui crearemos nuestras rutas

module.exports = router;
