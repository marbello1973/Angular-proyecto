// import {todo lo que voy a necesitar} from "donde_este.js"

exports.ejemplo = async (req, res) => {
  return res.status(200).send({ message: "Chau mundo!!" });
};
